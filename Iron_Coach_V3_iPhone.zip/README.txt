IRON COACH V3 — iPHONE / PWA

Qué se corrigió:
- Navegación y botones con event listeners explícitos (más robusto en Safari).
- Onboarding profesional.
- Interfaz premium mobile-first.
- Guardado local con aviso si falla.
- Coach de carga, RIR, PR, e1RM, gráficos, historial y ranking.
- Ranking Hierro → Challenger basado en fuerza relativa + consistencia.
- Manifest y service worker para instalación PWA.

IMPORTANTE SOBRE IPHONE:
Un archivo HTML abierto desde Archivos/Quick Look NO es una app web instalada. Para usar “Agregar a pantalla de inicio”, estos archivos deben estar publicados por HTTPS. La carpeta está lista para hosting estático.

Después de publicar:
Safari > abrir URL > Compartir > Agregar a pantalla de inicio > Abrir como app.

Limitaciones todavía externas:
- login real por email
- sincronización nube
- push remoto con app cerrada
- WhatsApp automático
- pagos / App Store
Todas requieren backend/servicios externos y forman parte de la etapa comercial.
